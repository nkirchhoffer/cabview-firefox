function getTabs(tabs) {
    document.getElementById('tabs').innerHTML = tabs.length;
    console.log(tabs.length);
}

browser.tabs.query({currentWindow: true}, getTabs)