browser.tabs.onActivated.addListener((activeInfo) => {
    browser.tabs.get(activeInfo.tabId).then(tab => {
        if (tab.url.match(/https:\/\/www\.youtube\.com\/watch\?v=(.*)/g)) {
            console.log('icone');
            browser.browserAction.setIcon({
                path: {
                    16: "icons/train-16.png",
                    32: "icons/train-32.png",
                    64: "icons/train-64.png"
                }
            });
        } else {
            browser.browserAction.setIcon({
                path: {
                    16: "icons/train-gray-16.png",
                    32: "icons/train-gray-32.png",
                    64: "icons/train-gray-64.png"
                }
            });
        }
    });
});

browser.browserAction.onClicked.addListener(tab => {
    if (tab.url.match(/https:\/\/www\.youtube\.com\/watch\?v=(.*)/g)) {
        const request = new XMLHttpRequest();
        request.open('POST', 'https://cabview.nkir.ch/api/videos');
        request.setRequestHeader('Content-Type', 'application/json');
        request.send(JSON.stringify({ video: tab.url }));
        request.onload = () => {
            browser.notifications.create('cake-notification', {
                type: 'basic',
                iconUrl: browser.runtime.getURL('icons/train-64.png'),
                title: 'CabView',
                message: 'Vidéo envoyée avec succès !'
            });
        }
    }
});